To make or build just type

make

To test: -
1) Just stereo sound from one stereo jack: -
./speaker-test -Dplug:front -c2
2) A 4 speaker setup from two stereo jacks: -
./speaker-test -Dplug:surround40 -c4
3) A 5.1 speaker setup from three stereo jacks: -
./speaker-test -Dplug:surround51 -c6

