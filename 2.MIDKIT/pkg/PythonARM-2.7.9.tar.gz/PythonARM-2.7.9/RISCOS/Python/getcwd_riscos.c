char *getcwd(char *buf, int size)
{
  buf[0] = '\0';
  return buf;
}
